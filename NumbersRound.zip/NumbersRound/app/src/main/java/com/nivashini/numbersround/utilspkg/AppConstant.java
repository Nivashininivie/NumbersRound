package com.nivashini.numbersround.utilspkg;

public class AppConstant {

    public static final String SHARED_PREF_NAME = "Numbersrounding_SharedPref";
    public static final String APP_FOLDER_NAME = "Numbers Rounding";
    public static final int PRIVATE_MODE = 0;
    public static final int DOC_ADD_REQUEST_CODE = 123;
    public static final int DOC_EDIT_REQ_CODE = 456;
    public static final int PERMISSION_WRITE_REQ_CODE = 789;
    public static final String EMAIL = "Email";
    public static final String PASWD = "Paswd";
}
