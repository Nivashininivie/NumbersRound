package com.nivashini.numbersround;

import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    String[] strSmallNos = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
    int[] smallNosArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int[] bigNosArray = {25, 50, 75, 100};

    LinearLayout linLayViewCont;
    MaterialButton btnGenerate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linLayViewCont = findViewById(R.id.linLayParent);
        btnGenerate = findViewById(R.id.btnGenerate);

        generateDynLayouts();

//        Collections.shuffle();
    }

    private void generateDynLayouts() {
        TableRow trBigNoCont = new TableRow(this);
        TableRow trSmallNocont1 = new TableRow(this);
        TableRow trSmallNocont2 = new TableRow(this);
        TableRow trSmallNocont3 = new TableRow(this);
        TableRow trSmallNocont4 = new TableRow(this);
        int count = 0;

        TableRow.LayoutParams trLayoutParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        trLayoutParams.setMargins(16, 16, 16, 16);
        List<Integer> bigNolist = new ArrayList<>(), smallNoList = new ArrayList<>();
        for (int i : bigNosArray)
            bigNolist.add(i);
        Collections.shuffle(bigNolist, new Random());

        for (int j : smallNosArray)
            smallNoList.add(j);
        Collections.shuffle(smallNoList, new Random());

        int[] androidColors = getResources().getIntArray(R.array.random_colors_array);


        for (int bigNo : bigNolist) {
            int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
            TextView tvBigNoTextView = new TextView(this);
            tvBigNoTextView.setLayoutParams(trLayoutParams);
            tvBigNoTextView.setBackground(getResources().getDrawable(R.drawable.btn_filled_box_bg));
            tvBigNoTextView.setBackgroundColor(randomAndroidColor);
            tvBigNoTextView.setGravity(Gravity.CENTER);
            tvBigNoTextView.setPadding(24, 48, 24, 48);
            tvBigNoTextView.setText(String.valueOf(bigNo));
            trBigNoCont.addView(tvBigNoTextView);
        }
        for (int smallNo = 0; smallNo < smallNoList.size(); smallNo++) {

            if (smallNo < 5) {
                int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
                TextView tvSmallNoTextView = new TextView(this);
                trSmallNocont1.setWeightSum(5);
                tvSmallNoTextView.setLayoutParams(trLayoutParams);
                tvSmallNoTextView.setText(String.valueOf(smallNoList.get(smallNo)));
                tvSmallNoTextView.setGravity(Gravity.CENTER);
                tvSmallNoTextView.setBackground(getResources().getDrawable(R.drawable.btn_filled_box_bg));
                tvSmallNoTextView.setBackgroundColor(randomAndroidColor);
                tvSmallNoTextView.setPadding(4, 24, 4, 24);
                trSmallNocont1.addView(tvSmallNoTextView);
            } else if (smallNo < 10) {
                int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
                trSmallNocont2.setWeightSum(5);
                TextView tvSmallNoTextView = new TextView(this);
                tvSmallNoTextView.setLayoutParams(trLayoutParams);
                tvSmallNoTextView.setText(String.valueOf(smallNoList.get(smallNo)));
                tvSmallNoTextView.setBackgroundColor(randomAndroidColor);
                tvSmallNoTextView.setGravity(Gravity.CENTER);
                tvSmallNoTextView.setBackground(getResources().getDrawable(R.drawable.btn_filled_box_bg));
                tvSmallNoTextView.setBackgroundColor(randomAndroidColor);
                tvSmallNoTextView.setPadding(4, 24, 4, 24);
                trSmallNocont2.addView(tvSmallNoTextView);
            }
        }
        for (int j : smallNosArray)
            smallNoList.add(j);
        Collections.shuffle(smallNoList, new Random());

        for (int smallNo = 0; smallNo < smallNoList.size(); smallNo++) {

            if (smallNo < 5) {
                int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
                TextView tvSmallNoTextView = new TextView(this);
                trSmallNocont1.setWeightSum(5);
                tvSmallNoTextView.setLayoutParams(trLayoutParams);
                tvSmallNoTextView.setText(String.valueOf(smallNoList.get(smallNo)));
                tvSmallNoTextView.setGravity(Gravity.CENTER);
                tvSmallNoTextView.setBackground(getResources().getDrawable(R.drawable.btn_filled_box_bg));
                tvSmallNoTextView.setBackgroundColor(randomAndroidColor);
                tvSmallNoTextView.setPadding(4, 24, 4, 24);
                trSmallNocont3.addView(tvSmallNoTextView);
            } else if (smallNo < 10) {
                int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
                trSmallNocont2.setWeightSum(5);
                TextView tvSmallNoTextView = new TextView(this);
                tvSmallNoTextView.setLayoutParams(trLayoutParams);
                tvSmallNoTextView.setText(String.valueOf(smallNoList.get(smallNo)));
                tvSmallNoTextView.setGravity(Gravity.CENTER);
                tvSmallNoTextView.setBackground(getResources().getDrawable(R.drawable.btn_filled_box_bg));
                tvSmallNoTextView.setBackgroundColor(randomAndroidColor);
                tvSmallNoTextView.setPadding(4, 24, 4, 24);
                trSmallNocont4.addView(tvSmallNoTextView);
            }
        }
        linLayViewCont.addView(trBigNoCont);
        linLayViewCont.addView(trSmallNocont1);
        linLayViewCont.addView(trSmallNocont2);
        linLayViewCont.addView(trSmallNocont3);
        linLayViewCont.addView(trSmallNocont4);
    }
}
